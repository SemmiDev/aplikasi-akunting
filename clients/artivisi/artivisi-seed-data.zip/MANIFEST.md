# Data Export Manifest

Export Date: 2025-12-02 20:07:30
Application: Aplikasi Akunting
Format Version: 2.0

## Company Information
Name: PT Artivisi Intermedia
NPWP: -

## Export Contents
- Chart of Accounts: 83 records
- Journal Templates: 58 records
- Journal Entries: 0 records
- Transactions: 0 records
- Clients: 0 records
- Projects: 0 records
- Invoices: 0 records
- Employees: 0 records
- Payroll Runs: 0 records
- Users: 0 records
- Documents: 0 files
- Audit Logs: 0 records

## Notes
This is a seed data export containing only:
- Chart of Accounts (Artivisi IT Services COA v2.1)
- Journal Templates (Artivisi templates v2.1)

All other tables are empty placeholders.
